/* package codechef; // don't place package name! */

import java.util.*;
import java.lang.*;
import java.io.*;

/* Name of the class has to be "Main" only if the class is public. */
public class Main
{
    public static void decreasingOrder(PriorityQueue<Integer> minHeap){
        if(minHeap.size() == 0){
            return;
        }
        int ele = minHeap.remove();
        decreasingOrder(minHeap);
        System.out.print(ele+ " ");
    }
	public static void main (String[] args) throws java.lang.Exception
	{
// 		int arr[] = {1,2,34,5,67,8,54};
// For 2nd test case you need to comment out 2nd input, make sure before uncommenting 2nd one please comment it 1st one. 
        int arr[] = {121,2324,3454,5443,235,23423,6876,998,2433,5463,3432,3495};
        PriorityQueue<Integer> minHeap = new PriorityQueue<>();
        for(int i=0; i<3; i++){
            minHeap.add(arr[i]);
        }
        for(int i=3; i< arr.length; i++){
            if(arr[i] > minHeap.peek()){
                minHeap.remove();
                minHeap.add(arr[i]);
            }
        }
        decreasingOrder(minHeap);
	}
}

//Time Complexity: O(n*log(3))                                        //Space complexity: O(3)

