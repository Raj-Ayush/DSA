import java.io.*;
import java.util.*;


public class Main
{
    public static String reverseWithRecursion(String str, int i, String newStr){
        if(i < 0){
            return newStr;
        }
        newStr += str.charAt(i);
        return reverseWithRecursion(str, --i, newStr);
    }
    public static String reverseWithIterative(String str){
        String newStr = "";
        for(int i=str.length()-1; i>= 0; i--){
            newStr += str.charAt(i); 
        }
        return newStr;
    }
	public static void main(String[] args) {
	   // String str= "ajkhduygfybhrhejubqpewyuevg";
	   
	    String str= "ajhuygyefvbyufgefehgquy";
	    String newStr = reverseWithRecursion(str, str.length()-1, "");
	    System.out.println("Reverse with Recursion: "+ newStr);
	    System.out.println("Time complexity: O(n)               Space complexity: O(n)");
	    
	    //Time complexity: O(n)               Space complexity: O(n)
	    
	    System.out.println("Reverse with Iterative: "+ reverseWithIterative(str));
	    System.out.print("Time complexity: O(n)               Space complexity: O(1)");
	    
	    //Time complexity: O(n)               Space complexity: O(1)
	}
}


