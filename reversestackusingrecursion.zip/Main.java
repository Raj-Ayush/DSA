import java.util.*;
 
class Main
{ 
 

    static void reverse(Stack<Integer> s) 
    { 
        if (s.isEmpty()) 
            return; 
        int x = s.peek(); 
        s.pop(); 
        reverse(s); 
        reverseStack(s,x);
    } 
    static void reverseStack(Stack<Integer> s, int x){
        if(s.empty()){
            s.push(x);
            return;
        }
        int top = s.peek();
        s.pop();
        reverseStack(s, x);
        s.push(top);
    }
     
    public static void main(String[] args) 
    { 
        Stack<Integer> s = new Stack<>(); 
        s.push(1); 
        s.push(2); 
        s.push(3); 
        s.push(4); 
        System.out.println("Before reverse: "+ s);
         reverse(s); 
        System.out.print("After Reverse:  "+ s);
       
        
    }
} 