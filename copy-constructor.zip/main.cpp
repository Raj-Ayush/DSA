#include<iostream>
using namespace std;
class complex{
    int real , img;
    public:
    complex(int real, int img){
        this->real = real;
        this->img = img;
    }
    complex(int r){  // constructor with one arguement
        real = r;
        img = 0;
    }
    complex(){}    //default contructor
    void display(){
        cout<<real<<" + "<< img <<"i"<<endl;
    }
    complex(complex &c){       
        real = c.real;                  
        img = c.img;           
    }
    ~complex(){
        cout<<"\n"<<"I am destructor"<<endl;
    }
};
int main(){

    complex c1,c2(3,4); 

    c1.display();
    c2.display();
    //c2.display();
    //c3.display();
}
