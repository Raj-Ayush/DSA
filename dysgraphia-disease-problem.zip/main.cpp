#include<iostream>
using namespace std;
int mindivchange(int num){
    int quo= num;
    int sum= 0, rem;
    int temp =1;
    
    while(quo){
        rem= quo %10;
        if(rem==6){
            rem = 5;
        }
        sum= sum+ rem*temp;
        temp = temp*10;
        quo= quo/10;
    }
    //cout<<sum<<"\n";
    return sum;
}
int maxdivchange(int num){
    int quo= num;
    int sum= 0, rem;
    int temp =1;
    
    while(quo){
        rem= quo %10;
        if(rem==5){
            rem = 6;
        }
        sum= sum+ rem*temp;
        temp = temp*10;
        quo= quo/10;
    }
    //cout<<sum<<"\n";
    return sum;
}
int minSum(int a, int b){
    return mindivchange(a) + mindivchange(b);
    
}

int maxSum(int a, int b){
    return maxdivchange(a) + maxdivchange(b);
}
int main(){
    int a, b;
    cin>>a;
    cin>>b;
    cout<<minSum(a, b)<<" "<<maxSum(a, b)<<endl;
}