import java.util.*;
import java.lang.*;
import java.io.*;


class pair{
        public int key, value;
        
        pair(int key, int value){
            this.key= key;
            this.value= value;
        }
    }

public class Main
{
    // public static void printmostOccurenceInDecrasing(PriorityQueue pq, HashMap<Integer, Integer> hm){
    //     if(pq.size() == 0){
    //         return;
    //     }
    //     pair mostOccurence = (pair)pq.remove();
    //     printmostOccurenceInDecrasing(pq, hm);
    //     System.out.println(mostOccurence.key+": "+ mostOccurence.value);
    // }
	public static void main(String[] args) {
		int arr[]= {1,2,34,5,67,8,54, 67,8,54,1,2,34,5,67,34,5,67,8};
		int k = 3;
		
//      For 2nd test case you need to comment out 2nd input, make sure before
// 		uncommenting 2nd one please comment it 1st one. 
		
// 		int arr[]= {121,2324,3454,5443,235,23423,6876,998,2433,5463,3432,3495, 3454,5443,235,23423,6876,2324,3454,5443};
// 		int k = 5;

		HashMap<Integer, Integer> hm = new HashMap<>();
		PriorityQueue<pair> minHeap = new PriorityQueue<>((pair1, pair2)-> 
		                                                hm.get(pair1.key).equals(hm.get(pair2.key))
		                                                ?Integer.compare(pair2.key, pair1.key)
		                                                :
		                                                Integer.compare(hm.get(pair2.key),hm.get(pair1.key)));
		for(int i=0; i<arr.length; i++){
		    if(hm.containsKey(arr[i])){
		        hm.put(arr[i], hm.get(arr[i])+1);
		    }
		    else{
		        hm.put(arr[i], 1);
		    }
		}
		for(Map.Entry<Integer, Integer> entry :hm.entrySet()){
            int key = (int)entry.getKey();
            int value = (int)entry.getValue();
            minHeap.add(new pair(key, value));
        }
        for(int i=0; i<k; i++){
            pair mostOccurence = (pair)minHeap.remove();
            System.out.println(mostOccurence.key+": "+ mostOccurence.value);
        }
	}
}

//Time complexity: O(klog(n))                                    Space complexity: O(z)
//where n is the length of the array and k is the numbers with most occurences.  
//z is the distinct number which is store in the HashMap.



