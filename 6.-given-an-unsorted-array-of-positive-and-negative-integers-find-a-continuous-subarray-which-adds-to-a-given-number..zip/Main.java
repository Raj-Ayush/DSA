import java.util.*;
import java.io.*;


public class Main
{
    public static void prefixAlgo(int arr[], int k){
        HashMap <Integer, Integer> hm = new HashMap<>();
        int start =0;
        int end= -1;
        int currSum= 0;
        for(int i=0; i< arr.length; i++){
            currSum += arr[i]; 
            if(currSum - k == 0){
                start = 0;
                end = i;
                break;
            }
            if(hm.containsKey(currSum - k)){
                start = hm.get(currSum - k)+1;
                end = i;
                break;
            }
            hm.put(currSum, i);
        }
        if(end == -1){
            System.out.print("No Subarray Found!");
        }else{
            System.out.print("Subarray found with index "+ start + " to "+ end);
        }
    } 
	public static void main(String[] args) {
		int arr[]= {1,23,34,56,78,90};
		int k =168;

//      For 2nd test case you need to comment out 2nd input, make sure before
// 		uncommenting 2nd one please comment it 1st one.
		
// 		int arr[]= {1,23,34,56,78,90, -1, -2, -3, -4, -12, 45, 90, 100, 85 };
// 		int k =203;
		prefixAlgo(arr, k);
	}
}

//Time complexity: O(n)                                          Space complexity: O(n)


