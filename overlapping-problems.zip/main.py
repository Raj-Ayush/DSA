
def overlap(v):
    ans = 0
    count = 0
    data = []
    for i in range(len(v)):
        data.append([v[i][0], 'x'])
        data.append([v[i][1], 'y'])
    data = sorted(data)
    for i in range(len(data)):
        if (data[i][1] == 'x'):
            count += 1
        if (data[i][1] == 'y'):
            count -= 1
        ans = max(ans, count)
    return ans

row = int(input())
col = int(input())
lis = []
for i in range(row):
    lis.append(list(map(int, input().split())));

 
print(overlap(lis))   
 
   