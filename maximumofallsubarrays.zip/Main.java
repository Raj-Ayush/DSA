import java.io.*; // for handling input/output
import java.util.*; 
public class Main
{
	public static void main(String[] args)throws Exception {
		Scanner sc = new Scanner(System.in);
		int n = 5;
		int k = 3;
		int arr[] = {1, 2, 3, 4, 5};
		Deque <Integer> d = new ArrayDeque<>();
		for(int i = 0; i < k; i++){
            while(!d.isEmpty() && arr[d.peekLast()]< arr[i])
            {
                d.removeLast();
            }
            d.addLast(i);
		}
		int currIndex = k;
		 while(currIndex < n){
            System.out.print(arr[d.peekFirst()] + " ");
            int curr = arr[currIndex];
            while(!d.isEmpty() && curr > arr[d.peekLast()]){
                d.removeLast();
            }
            d.addLast(currIndex);
            while(!d.isEmpty() && d.peekFirst() <= (currIndex - k)){
                d.removeFirst();
            }
            currIndex++;
        }
        System.out.print(arr[d.peekFirst()]);
	}
}
