#include<iostream>
using namespace std;
class Account{
private:
    int balance;
    static float roi;
public:
    void setBalance(int b){
        balance = b;
    }
    void display(){
        cout<<balance<<endl;;
        //cout<<roi;
    }
    float si(){
        int s = (balance*roi*1)/100;
        return s;
    }
    static void setroi(float r){
        roi = r;
    }
};
float Account :: roi; //static data members

int main(){
    Account obj1, obj2;
    obj1.setBalance(5000);
    obj2.setBalance(8000);
    Account::setroi(3.5);
    obj1.display();
    obj2.display();
    cout<<obj1.si()<<"\n";
    cout<<obj2.si()<<"\n";

}
