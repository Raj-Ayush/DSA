import java.util.*;
public class Main
{
	public static void main(String[] args) {
	Scanner sc = new Scanner(System.in);
      ArrayList <String> list = new ArrayList<String>(10);
      String line = sc.nextLine();
        while (line.charAt(0) !='q' ) 
        { 
          list.add(line);
          line = sc.nextLine();
        }
       
        for (int i = 0; i < list.size();i++) 
	      { 		      
	          System.out.println(list.get(i)); 		
	      }   
	}
}


