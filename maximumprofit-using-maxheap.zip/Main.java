import java.io.*; // for handling input/output
import java.util.*; 
public class Main
{
	public static void main(String[] args) {
		int a[] = {3,6,5,1,8,0};
		int n = 3;
		PriorityQueue<Integer> pq = new PriorityQueue<>(Collections.reverseOrder());
		for(int i=0; i<a.length; i++){
		    pq.add(a[i]);
		}
		int maxp = 0;
		for(int i= 0; i< n; i++){
		   int x = pq.remove();
		   maxp += x;
		   x--;
		   pq.add(x);
		}
        System.out.print(maxp);
	}
}
