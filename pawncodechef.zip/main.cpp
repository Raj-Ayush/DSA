#include <iostream>
using namespace std;

int main() {
	// your code goes here
	int test;
	cin>>test;
	for(int i = 0; i<test;i++){
	    int N, K;
	    cin>>N>>K;
	    int *P = new int[N];
	    for (int i = 0; i < N; i++){
	        cin>>P[i];
	    }
	    int small =  10*9, P1 = -1;
	    for(int i = 0; i < N; i++){
	        int count = 0, sum = 0;
	        sum = P[i];
	        while(1){
	           sum += P[i];
	           count++;
	           if (sum == K){
	               break;
	           }
	           else if (sum > K){
	               count = 0;
	               break;
	               
	           }
	       }
	       if(small > count && count !=0 ){
	            small = count;
	            P1 = P[i];
	        }
	    }
	    cout << P1<<"\n";
	}
	return 0;
}
