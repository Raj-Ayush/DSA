import java.io.*;
import java.util.*;

public class Main
{
    public static boolean checkPowerof2(int x){
        if(x == 0){
            return false;
        }
        if((x & x-1) == 0){
            return true;
        }
        return false;
    }
    public static void deleteCharacter(int freq, int index, String str[], char charSearch){
        while(freq > 0){
            if(str[index].charAt(0) == charSearch){
                str[index] = "";
                freq--;
            }
            index++;
        }
    }
	public static void main(String[] args) {
       int arr[] = new int[130];
// 		String str= "!@#$*%*#!@(*#saAsSAaaassdsdsjfhubvbAKHHWUAHFUIINEW";
		
		String str= "!@%@&%@&*#*&*^&&&^^^^(@!*&aaaaayyyyuuuuuuuuwwwwwwwwwwwwwwwwAYUUHSKJHSYYYYYYYYUUUUUUUUUUUUUUUUnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn";
		String str1[] = str.split("");
		for(int i=0; i< str.length(); i++){
		    arr[str.charAt(i)]++;
		}
		for(int i=0; i< str.length(); i++){
		    char curr = str.charAt(i);
		  //  System.out.println(i+": "+ curr+ ": "+str.charAt(i));
		  
		    if(Character.isLowerCase(curr)){
		        if(checkPowerof2(arr[curr])){
		            int j = i;
		            int frequency = arr[curr];
		            deleteCharacter(frequency, j, str1,curr);
		            arr[curr]= 0;
		          //  System.out.println(curr +""+ frequency);
		        }
		    }
		}
		String newStr= "";
		for(int i=0; i<str1.length; i++){
		    newStr += str1[i];
		}
		System.out.println(newStr);
	}
}

//Time Complexity : O(n*k)                             Space Complexity: O(z);

//Where k is the frequency of each lowercase character should be deleted..
//Where z is the size of hashmap...



