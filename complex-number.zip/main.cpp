//Adding two complex number.
#include<iostream>
using namespace std;
class Complex{
    int real, img;
    public:
    void setdata(int, int);
    Complex operator +(Complex c){
        Complex temp;
        temp.real = real + c.real;
        temp.img = img + c.img;
        return(temp);
    }                                                 
    void display();
};
void Complex :: setdata(int a, int b){
    real = a;
    img = b;
}

void Complex :: display(){
    cout<<real<<"+("<<img<<"i)";
}

int main(){
    Complex c1,c2,c3;
    c1.setdata(4,5);
    c2.setdata(8,9);
   // c4.setdata(6,4);
   c3 = c1 + c2;
    c3.display();
}
