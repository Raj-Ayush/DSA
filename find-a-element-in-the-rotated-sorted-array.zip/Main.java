/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
public class Main
{
    static int FindRotation(int arr[], int low ,int high){
        while(low <= high){
            if(arr[low] <= arr[high]){
                return low;
            }
            int mid = (high - low + 1)/2;
            int prev = (mid + high)% (high + 1);
            int next = (mid + 1)% (high + 1);
            if(arr[mid] <= arr[next] && arr[mid] <= arr[prev]){
                return mid;
            }
            else if (arr[mid] <= arr[high]){
                high = mid - 1;
            }
            else if(arr[mid] >= arr[low]){
                low = mid + 1;
            }
        }
        return -1;
    }
    static int bs(int arr[], int start, int end, int value){
        while(start <= end){
            int mid = start + (end - start )/2;
            if(arr[mid] == value){
                return mid;
            }
            else if(arr[mid] > value){
                end = mid - 1;
            }
            else if(arr[mid] < value){
                start = mid + 1;
            }
        }
        return -1;
    }
	public static void main(String[] args) {
	    int arr[] = {4, 5, 6, 7, 2, 3};
	    int min = FindRotation(arr, 0 , 5);
	    int in1 = bs(arr, 0, min - 1, 4);
	    int in2 = bs(arr, min, 5, 4);
	    int x = in1 > in2 ? in1 : in2;
	    System.out.print(x);
	}
}
