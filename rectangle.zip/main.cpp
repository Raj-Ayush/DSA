#include<iostream>
using namespace std;
class Rectangle{
    private: 
    int len, bre;
    public:
    void setdata(int , int );
    int area(){
       return(len*bre); 
    }
};
void Rectangle:: setdata(int l, int b){ // here define function from outside of that class, here :: 
                                        // operator is called scope resolution operator.
    len = l;
    bre = b;
}
 int main(){
     Rectangle obj1,obj2, obj3;
     obj1.setdata(3,4);
     obj2.setdata(5,6);
     obj3.setdata(7,8);
     cout<<obj1.area()<<"\n"<<obj2.area()<<"\n"<<obj3.area()<<endl;
     
 }