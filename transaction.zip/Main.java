/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.*;
public class Main
{
	public static void main(String[] args) {
         Scanner sc= new Scanner(System.in);
         String str= sc.nextLine();
         String[] str1 = str.split(",");
         int sum = 0;
         for(int i = 0; i< str1.length; i++){
             String[] str5 = str1[i].split("-");
             int value = Integer.parseInt(str5[0]);
             //System.out.print(str5[1]);
             if(str5[1].equals("W")){
                 sum-= value;
                 //System.out.println("H");
             }
             else {
                 sum+=value;
             }
         }
         if (sum > 5000){
             sum = (int)(sum + (double)(sum*0.05));
         }
         System.out.println(sum);
     }
}

