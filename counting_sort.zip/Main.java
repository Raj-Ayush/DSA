/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.io.*; // for handling input/output
import java.util.*;
public class Main
{
    static int findMax(int arr[], int n){
        int max = Integer.MIN_VALUE;
        for(int i=0; i<n; i++){
            max = arr[i] > max ? arr[i]: max; 
        }
        return max;
    }
    static void countingSort(int arr[], int B[], int n, int k){
        int c[] = new int[k+1];
        Arrays.fill(c,0);
        for(int i=0; i<n; i++){
            c[arr[i]]++;
        }
        for(int i=1; i<k; i++){
            c[i] += c[i-1];
        }
        for(int i= n-1; i >= 0; i--){
            B[c[arr[i]]-1] = arr[i];
            c[arr[i]] -= 1;
        }
    }
	public static void main(String[] args) {
	    Scanner sc = new Scanner(System.in);
	    int n = 8;
	    int arr[] = {2,5,3,0,2,3,0,3};
	   // for(int i=0; i<n; i++){
	   //     arr[i] = sc.nextInt();
	   // }
	    int k = findMax(arr, n);
	    int B[] = new int[n];
	    countingSort(arr, B, n, k+5);
	    for(int i=0; i<n; i++){
	        System.out.print(B[i] + " ");
	    }
	    
	}
}
