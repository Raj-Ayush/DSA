/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
public class Main
{
    public static void reverseStackUsingRecursion(int st[], int top){
        if(top < 0){
            return ;
        }
        int topData = st[top--];
        reverseStackUsingRecursion(st, top);
        System.out.print(topData+ " ");
    }
	public static void main(String[] args) {
		int stack[] = {1,2,34,5,67,8,54};
		//Given array is treated as stack so, its top value should be last element.
// For 2nd test case you need to comment out 2nd input, make sure before 
// uncommenting 2nd one please commenting 1st one. 
		
// 		int stack[] = {121,2324,3454,5443,235,23423,6876,998,2433,5463,3432,3495};
        reverseStackUsingRecursion(stack, stack.length-1);
	}
}

//Time complexity : O(n)                               Space complextiy: O(n)

